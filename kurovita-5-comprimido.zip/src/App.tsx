import React, { useState, useEffect, useRef } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { MariaStory } from "./components/MariaStory";
import { ShockVideo } from "./components/ShockVideo";
import { Checklist } from "./components/Checklist";
import { WhatsAppReviews } from "./components/WhatsAppReviews";
import { TimelineVertical } from "./components/TimelineVertical";
import { PricingOffers } from "./components/PricingOffers";
import { Reviews } from "./components/Reviews";
import { Faq } from "./components/Faq";
import { Footer } from "./components/Footer";
import { StickyBar } from "./components/StickyBar";
import { SalesToast } from "./components/SalesToast";
import { ExitIntentModal } from "./components/ExitIntentModal";
import { StockBadgeFloating } from "./components/StockBadgeFloating";
import { BEFORE_AFTER_ITEMS, KITS, KITS_DISCOUNTED_30, KitOffer } from "./data/intestpuraData";
import { detectUserLocation, GeoLocation } from "./services/geoService";

export default function App() {
  const [discountApplied, setDiscountApplied] = useState(false);
  const [selectedKit, setSelectedKit] = useState<KitOffer | null>(KITS[0]); // default to Most Popular kit
  
  // Persistência por sessão (sessionStorage)
  const [stock, setStock] = useState<number>(() => {
    if (typeof window !== "undefined") {
      try {
        const saved = sessionStorage.getItem("intestpura_session_stock");
        if (saved !== null) {
          const parsed = parseInt(saved, 10);
          if (!isNaN(parsed) && parsed >= 17 && parsed <= 219) {
            return parsed;
          }
        }
      } catch {
        // Fallback se sessionStorage não estiver acessível
      }
    }
    return 219;
  });

  const [hasError, setHasError] = useState(false);
  const [showSticky, setShowSticky] = useState(false);
  const [userGeo, setUserGeo] = useState<GeoLocation | null>(null);
  const [cta2Highlighted, setCta2Highlighted] = useState(false);
  const cta2BtnRef = useRef<HTMLAnchorElement | null>(null);

  const touchStartPos2 = useRef<{ x: number; y: number } | null>(null);
  const isDragging2 = useRef(false);

  const handleTouchStart2 = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    touchStartPos2.current = { x: touch.clientX, y: touch.clientY };
    isDragging2.current = false;
  };

  const handleTouchMove2 = (e: React.TouchEvent) => {
    if (!touchStartPos2.current) return;
    const touch = e.touches[0];
    const diffX = Math.abs(touch.clientX - touchStartPos2.current.x);
    const diffY = Math.abs(touch.clientY - touchStartPos2.current.y);
    if (diffX > 8 || diffY > 8) {
      isDragging2.current = true;
    }
  };

  const currentKits = discountApplied ? KITS_DISCOUNTED_30 : KITS;

  // Detect user geolocation
  useEffect(() => {
    let isMounted = true;
    detectUserLocation().then((geo) => {
      if (isMounted && geo) {
        setUserGeo(geo);
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Sync session storage on stock change
  useEffect(() => {
    try {
      sessionStorage.setItem("intestpura_session_stock", String(stock));
    } catch {
      // Ignore
    }
  }, [stock]);

  // Handler to apply 30% discount when user closes exit-intent modal
  const handleApplyDiscount = () => {
    setDiscountApplied(true);
    setSelectedKit((prev) => {
      const match = KITS_DISCOUNTED_30.find((k) => k.id === prev?.id);
      return match || KITS_DISCOUNTED_30[0];
    });
  };

  // Discount dynamic stock on sales toast
  const handleSaleNotice = (bottles: number) => {
    setStock((prev) => {
      const next = Math.max(17, prev - bottles);
      try {
        sessionStorage.setItem("intestpura_session_stock", String(next));
      } catch {
        // Ignore
      }
      return next;
    });
  };

  const handleSelectKit = (kit: KitOffer) => {
    setSelectedKit(kit);
    setHasError(false);
  };

  const handleSelectKit2 = (kit: KitOffer) => {
    if (isDragging2.current) {
      isDragging2.current = false;
      return;
    }

    handleSelectKit(kit);

    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      try {
        navigator.vibrate([40, 30, 40]);
      } catch {
        // Ignore
      }
    }

    setCta2Highlighted(true);
    setTimeout(() => {
      setCta2Highlighted(false);
    }, 900);

    setTimeout(() => {
      if (cta2BtnRef.current) {
        cta2BtnRef.current.scrollIntoView({
          behavior: "smooth",
          block: "center",
        });
      }
    }, 60);
  };

  const handleBuyClick = (e: React.MouseEvent) => {
    if (!selectedKit) {
      e.preventDefault();
      setHasError(true);
      const target = document.getElementById("escolha-protocolo") || document.getElementById("offers");
      if (target) {
        target.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
  };

  const handleScrollToFirstOffers = (e: React.MouseEvent) => {
    e.preventDefault();
    const target = document.getElementById("escolha-protocolo") || document.getElementById("offers");
    if (target) {
      const header = document.querySelector("header");
      const headerHeight = header ? header.getBoundingClientRect().height : 60;
      const elementPosition = target.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - headerHeight - 10;
      window.scrollTo({
        top: Math.max(0, offsetPosition),
        behavior: "smooth",
      });
    }
  };

  // Scroll observer for sticky bar after #stickyTrigger
  useEffect(() => {
    const handleScroll = () => {
      const trigger = document.getElementById("stickyTrigger");
      if (!trigger) return;
      const rect = trigger.getBoundingClientRect();
      setShowSticky(rect.top <= window.innerHeight);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("resize", handleScroll);
    handleScroll();

    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleScroll);
    };
  }, []);

  return (
    <div className="min-h-screen">
      {/* 1. HEADER */}
      <Header />

      {/* BOLA LARANJA FLUTUANTE DE ESTOQUE */}
      <StockBadgeFloating stock={stock} />

      {/* 2. HERO (ADVERTORIAL / HEADLINE + GALERIA DE 3 FOTOS) */}
      <Hero />

      {/* 3. SHOCK BAND (ENDOSCOPIA DE MARIA GARCIA: VÍDEO DO EXAME EM MÁXIMO DESTAQUE) */}
      <section className="shock-sec">
        <div className="wrap">
          <div className="shock-wrap">
            <span className="shock-eyebrow">Endoscopia · Exame Clínico Real</span>
            <h2>
              Não é frescura. É isto que pode estar{" "}
              <span className="green">vivo no seu intestino agora</span>
            </h2>

            {/* TÍTULO FORMATADO, CENTRALIZADO E IMAGEM DO EXAME ANTES DO VÍDEO */}
            <div className="shock-video-header">
              <div className="maria-endo-photo-wrap">
                <img
                  src="https://cdn.shopify.com/s/files/1/1010/4150/4546/files/Cepon-1.jpg?v=1790297459"
                  alt="Maria Garcia realizando o exame de endoscopia"
                  className="maria-endo-photo"
                  loading="eager"
                  decoding="async"
                  referrerPolicy="no-referrer"
                />
                <span className="maria-endo-caption">
                  Maria Garcia realizando o exame de endoscopia
                </span>
              </div>

              <h3 className="svh-title" style={{ margin: "4px 0 0" }}>
                Vídeo gravado durante o exame da Maria Garcia <span className="highlight">⬇️</span>
              </h3>
            </div>

            {/* VÍDEO COM MÁXIMO FOCO E DESTAQUE */}
            <div className="shock-vid-focus-wrapper">
              <ShockVideo />
            </div>

            <p className="shock-cap">
              Exame endoscópico da paciente Maria Garcia: Biofilme mucoso e parasitas ativos bloqueando a absorção de nutrientes.
            </p>
          </div>
        </div>
      </section>

      {/* 4. REVEAL BAND (1 EM 3 MULHERES) */}
      <section className="reveal-sec">
        <div className="reveal-container anim in">
          <span className="rk">O que ninguém te conta</span>
          <div className="rnum">1 em 3</div>
          <h2 className="rhead">
            mulheres carregam parasitas escondidos por anos sem saber.
          </h2>
          <p className="rbody">
            E quase ninguém percebe a causa oculta. Os sintomas se confundem com cansaço,
            metabolismo lento e ganho de peso. Por isso a fórmula do Intestpura foi revelada —
            para quem cansou de dietas e canetas emagrecedoras, e quer exterminar a causa pela raiz.
          </p>
          <span className="rsrc">ⓘ Pesquisas parasitológicas e saúde do microbioma</span>

          <a
            href="#escolha-protocolo"
            onClick={handleScrollToFirstOffers}
            className="reveal-cta-btn"
          >
            Quero 67% de desconto!
          </a>

          <div style={{ marginTop: 24, width: "100%", maxWidth: 740, borderRadius: 16, overflow: "hidden", border: "1px solid #E5E7EB", boxShadow: "0 10px 28px rgba(0,0,0,0.08)" }}>
            <img
              src="https://cdn.shopify.com/s/files/1/1010/4150/4546/files/42fc8228-579b-4b37-a46d-de6ccd4dc168.png?v=1791250099"
              alt="Intestpura"
              loading="eager"
              referrerPolicy="no-referrer"
              style={{ width: "100%", height: "auto", display: "block" }}
            />
          </div>
        </div>
      </section>

      {/* 5. HISTÓRIA / ANTES E DEPOIS DE MARIA GARCIA (FUNDO BRANCO) */}
      <section className="sec-white maria-story-white-sec">
        <div className="wrap">
          <MariaStory />
        </div>
      </section>

      {/* 6. SINTOMAS E BIOFILME (SESSÃO UNIFICADA) */}
      <Checklist />

      {/* 7. DESCOBERTA DA CIÊNCIA: 3 ELEMENTOS NATURAIS (PUXADA PARA CIMA E RESUMIDA) */}
      <section className="sec-white">
        <div className="wrap">
          <h2 className="center anim in">
            A Descoberta da Ciência: 3 Elementos Naturais que{" "}
            <span className="green">Desestruturam o Biofilme e o Inchaço</span>
          </h2>
          <div className="ing3 anim in">
            <div className="card">
              <img
                src="/images/semente_abobora.jpg"
                alt="Sementes de Abóbora Naturais"
                className="card-img"
                loading="eager"
                decoding="async"
                onError={(e) => {
                  e.currentTarget.onerror = null;
                  e.currentTarget.src = "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Gelatidina_em_po_regula_o_intestino_1.jpg?v=1789415086";
                }}
              />
              <div className="card-content">
                <span className="tag">Propriedade Vermífuga Ancestral</span>
                <h3>Sementes de Abóbora</h3>
                <p>
                  Ricas no teor natural de <b>cucurbitacina</b>, fitoquímico com ação seletiva que paralisa e desprende os invasores das paredes intestinais, estimulando sua eliminação suave sem cólicas.
                </p>
              </div>
            </div>

            <div className="card">
              <img
                src="/images/cravo_india.jpg"
                alt="Cravo-da-Índia — Fonte de Eugenol"
                className="card-img"
                loading="eager"
                decoding="async"
                onError={(e) => {
                  e.currentTarget.onerror = null;
                  e.currentTarget.src = "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Gelatidina_em_po_regula_o_intestino.jpg?v=1789414477";
                }}
              />
              <div className="card-content">
                <span className="tag">Solvente Natural de Biofilme</span>
                <h3>Cravo-da-Índia</h3>
                <p>
                  Fonte concentrada de <b>eugenol bioativo</b>, fitoativo reconhecido pela capacidade de dissolver a armadura viscosa do biofilme, neutralizando ovos e combatendo a fermentação de gases.
                </p>
              </div>
            </div>

            <div className="card">
              <img
                src="/images/oleos_fitoterapicos.jpg"
                alt="Óleos Fitoterápicos Purificados — Drenagem Digestiva"
                className="card-img"
                loading="eager"
                decoding="async"
                onError={(e) => {
                  e.currentTarget.onerror = null;
                  e.currentTarget.src = "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Intestpura.png?v=1789330983";
                }}
              />
              <div className="card-content">
                <span className="tag">Drenagem & Alívio Digestivo</span>
                <h3>Óleos Fitoterápicos</h3>
                <p>
                  Frações purificadas que apoiam a varredura de amônia e toxinas estagnadas no cólon, acalmando os tecidos e devolvendo o abdômen naturalmente desinchado e leve.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. CRONOGRAMA: O QUE ACONTECE NO SEU CORPO DIA A DIA (LOGO ABAIXO DE ÓLEOS FITOTERÁPICOS) */}
      <TimelineVertical />

      {/* 9. MENSAGENS NO WHATSAPP */}
      <section className="sec-white" id="wa-reviews-sec" style={{ padding: "36px 0 10px" }}>
        <div className="wrap">
          <WhatsAppReviews />
        </div>
      </section>

      {/* 10. ANTES E DEPOIS DE CLIENTES (CARROSSEL DE FOTOS LOGO ABAIXO DOS DEPOIMENTOS DE WHATSAPP) */}
      <section style={{ paddingTop: 6, paddingBottom: 26 }}>
        <div className="wrap">
          <div className="ba-gallery anim in">
            {BEFORE_AFTER_ITEMS.map((item, idx) => (
              <div key={idx} className="ba-card">
                <img
                  src={item.img}
                  alt={item.alt}
                  loading="eager"
                  decoding="async"
                  onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/c8332e77-f32f-45ab-91a0-a1ce8df39c98.png?v=1789505217";
                  }}
                />
                <span className="ba-tag ba-tag-l">ANTES</span>
                <span className="ba-tag ba-tag-r">DEPOIS</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 11. SESSÃO DE OFERTAS / PREÇOS (NO MEIO DA PÁGINA) */}
      <PricingOffers
        selectedKit={selectedKit}
        onSelectKit={handleSelectKit}
        hasError={hasError}
        onBuyClick={handleBuyClick}
        userGeo={userGeo}
        discountApplied={discountApplied}
        kits={currentKits}
      />

      {/* 12. REVIEWS */}
      <Reviews />

      {/* 18. SECOND OFFER SECTION (OPÇÃO AO FINAL DA PÁGINA) */}
      <section className="sec-white" id="offer2">
        <div className="wrap">
          <h2 className="center anim in">
            Escolha o seu <span className="green">protocolo Intestpura</span> e comece hoje
          </h2>
          <div style={{ maxWidth: 640, margin: "26px auto 0" }}>
            {discountApplied && (
              <div className="discount-applied-banner">
                <div className="dab-header">
                  <span className="dab-fire">💥</span>
                  <span className="dab-title">30% DE DESCONTO EXCLUSIVO ATIVADO!</span>
                </div>
                <p className="dab-sub">
                  Oferta especial com links e preços reduzidos com Frete Grátis incluso para <b>{userGeo?.city || "sua região"}</b>:
                </p>
              </div>
            )}
            <div className={`offers anim in ${discountApplied ? "offers-discount-applied" : ""}`}>
              {currentKits.map((kit) => {
                const isSelected = selectedKit?.id === kit.id;
                return (
                  <div
                    key={`off2-${kit.id}`}
                    role="button"
                    tabIndex={0}
                    className={`offer ${isSelected ? "sel" : ""} ${
                      hasError ? "erro" : ""
                    } ${discountApplied ? "offer-discounted" : ""}`}
                    onTouchStart={handleTouchStart2}
                    onTouchMove={handleTouchMove2}
                    onClick={() => handleSelectKit2(kit)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        handleSelectKit2(kit);
                      }
                    }}
                  >
                    <span className={`offer-tag ${kit.tagClass}`}>
                      {kit.tag}
                    </span>
                    <span className="radio"></span>
                    <span className={`thumb ${kit.thumbClass}`}>
                      <img src={kit.image} alt={kit.title} loading="lazy" />
                      {!kit.hideQtyBadge && <i className="qty">{kit.qty}</i>}
                    </span>
                    <span className="offer-body">
                      <span className="offer-title">{kit.title}</span>
                      <br />
                      {kit.id === "kit-6" ? (
                        <>
                          <span className="offer-eco">
                            <span className="offer-eco-protocol">
                              Protocolo <strong>Completo</strong> 180 dias
                            </span>
                            <span className="offer-eco-dot"> · </span>
                            <strong className="offer-eco-save">
                              {kit.subtitle.includes("Desconto")
                                ? "Desconto de 30% aplicado"
                                : "Economize 67%"}
                            </strong>
                          </span>
                          {kit.bonusGift && (
                            <div className="offer-bonus-row">
                              <span className="offer-bonus-badge">
                                <span className="obb-icon">🎁</span>
                                <span className="obb-text">{kit.bonusGift}</span>
                              </span>
                            </div>
                          )}
                        </>
                      ) : (
                        <>
                          <span className="offer-eco">{kit.subtitle}</span>
                          {kit.bonusGift && (
                            <div className="offer-bonus-row">
                              <span className="offer-bonus-badge">
                                <span className="obb-icon">🎁</span>
                                <span className="obb-text">{kit.bonusGift}</span>
                              </span>
                            </div>
                          )}
                        </>
                      )}
                    </span>
                    <span className="offer-price">
                      <span className="offer-old">{kit.oldPrice}</span>
                      <span className="offer-new">{kit.newPrice}</span>
                    </span>
                  </div>
                );
              })}
            </div>
            <a
              ref={cta2BtnRef}
              href={selectedKit?.url || "#"}
              className={`cta js-buy ${cta2Highlighted ? "cta-selected-vibrate" : ""}`}
              data-buy-main=""
              onClick={handleBuyClick}
            >
              <span className="cta-gift-tag">
                <span className="cgt-icon">🎁</span>
                <span className="cgt-text">+ Brinde</span>
              </span>
              <span className="cta-main">Comprar Agora →</span>
              {selectedKit && (
                <span className="buy-kit">
                  <span className="bk-pill-icon">✓</span>
                  {selectedKit.title.replace(/\s*·\s*/g, " - ")} - {selectedKit.newPrice}
                </span>
              )}
            </a>
            <div className={`offer-aviso ${hasError ? "visivel" : ""}`}>
              Selecione uma opção para comprar
            </div>
            <div className="paystrip">
              <span className="ps-lock">🔒 Pagamento 100% seguro</span>
              <div className="pays">
                <svg className="pi"><use href="#pi-visa" /></svg>
                <svg className="pi"><use href="#pi-mc" /></svg>
                <svg className="pi"><use href="#pi-elo" /></svg>
                <svg className="pi"><use href="#pi-amex" /></svg>
                <svg className="pi"><use href="#pi-pix" /></svg>
              </div>
            </div>
            <p
              style={{
                textAlign: "center",
                fontSize: 12,
                color: "var(--cinza)",
                marginTop: 10,
              }}
            >
              🛡️ Garantia 90 dias · Frete Grátis (até 4 dias) · Sem efeitos colaterais
            </p>
          </div>
        </div>
      </section>

      {/* 19. FAQ (RESUMIDO) */}
      <Faq />

      {/* 20. FOOTER */}
      <Footer />

      {/* 21. STICKY PURCHASE BAR */}
      <StickyBar
        show={showSticky}
        selectedKit={selectedKit}
        onSelectOfferClick={handleScrollToFirstOffers}
      />

      {/* 22. LIVE SALES POPUP */}
      <SalesToast currentStock={stock} onSaleNotice={handleSaleNotice} />

      {/* 23. EXIT-INTENT RETENTION POPUP */}
      <ExitIntentModal
        userGeo={userGeo}
        onApplyDiscount={handleApplyDiscount}
      />
    </div>
  );
}
