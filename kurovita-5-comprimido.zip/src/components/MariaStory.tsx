import { IMAGE_MARIA_GARCIA_BEFORE_AFTER } from "../data/intestpuraData";

export function MariaStory() {
  return (
    <div className="maria-story-white-wrap anim in">
      {/* TÍTULO ANTES DA IMAGEM */}
      <h2 className="maria-story-white-title">
        O Antes e Depois de Maria Garcia: Da Dor da{" "}
        <span className="green">"Barriga de Grávida"</span> à Liberdade com Intestpura
      </h2>

      {/* IMAGEM ANTES E DEPOIS (COM FUNDO BRANCO) */}
      <div className="maria-story-white-card">
        <img
          src={IMAGE_MARIA_GARCIA_BEFORE_AFTER}
          alt="Antes e depois de Maria Garcia: à esquerda sem o IntestPura e à direita com a tia parasitologista"
          className="maria-story-white-img"
          loading="eager"
          decoding="async"
        />
      </div>
    </div>
  );
}
