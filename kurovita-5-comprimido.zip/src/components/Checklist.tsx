import { useState, useEffect, useRef } from "react";
import { SYMPTOMS } from "../data/intestpuraData";

export function Checklist() {
  const [checkedIds, setCheckedIds] = useState<number[]>([]);
  const [interacted, setInteracted] = useState(false);
  const [showFloatingBar, setShowFloatingBar] = useState(false);

  const sectionRef = useRef<HTMLElement>(null);
  const checklistRef = useRef<HTMLDivElement>(null);

  const toggleSymptom = (id: number) => {
    setInteracted(true);
    setCheckedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const count = checkedIds.length;
  const total = SYMPTOMS.length;
  const fillPct = total > 0 ? Math.round((count / total) * 100) : 0;

  let verdict = "Toque nos sinais acima para verificar seu nível de sobrecarga.";
  let isAlert = false;
  if (count === 0) {
    verdict = "Toque nos sinais acima para verificar seu nível de sobrecarga.";
  } else if (count <= 2) {
    verdict = "Atenção: seu organismo já apresenta sinais de sobrecarga parasitária e formação de biofilme.";
  } else {
    verdict =
      "⚠️ Sinal de alerta: parasitas e biofilme estão roubando seus nutrientes, travando seu metabolismo e estufando seu abdômen.";
    isAlert = true;
  }

  useEffect(() => {
    const handleScroll = () => {
      const checklistEl = checklistRef.current;
      if (!checklistEl) return;

      const rect = checklistEl.getBoundingClientRect();
      const viewportHeight = window.innerHeight || document.documentElement.clientHeight;

      // Exibe a barra fixa APENAS durante a parte de selecionar as opções (não antes, nem depois)
      const inView = rect.top <= viewportHeight * 0.75 && rect.bottom >= 100;
      setShowFloatingBar(inView);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    window.addEventListener("resize", handleScroll);
    handleScroll();

    return () => {
      window.removeEventListener("scroll", handleScroll);
      window.removeEventListener("resize", handleScroll);
    };
  }, []);

  return (
    <section ref={sectionRef} className="sec-white checklist-unified-section">
      <div className="wrap">
        <h2 className="center anim in">
          Você chama de "normal".
          <br />
          <span className="red">O seu corpo chama de alerta.</span>
        </h2>

        <div className="quiz-cta" style={{ margin: "14px auto 20px", maxWidth: 640 }}>
          <span>👉 Toque nos sintomas que você sente para medir o seu nível de sobrecarga parasitária</span>
        </div>

        {/* 5 SINAIS COM MARCADOR */}
        <div
          ref={checklistRef}
          className={`checklist anim in ${!interacted ? "hint" : ""}`}
          id="checklist"
        >
          {SYMPTOMS.map((s) => {
            const isChecked = checkedIds.includes(s.id);
            return (
              <label
                key={s.id}
                className={`chk ${isChecked ? "on" : ""}`}
                onClick={() => toggleSymptom(s.id)}
              >
                <span className="box"></span>
                <span className="chk-txt">
                  <span className="sname">{s.name}</span>
                </span>
              </label>
            );
          })}
        </div>

        {/* RESULTADO ESTÁTICO LOGO ABAIXO DO 5º SINAL COM A LINHA DE PROGRESSO */}
        <div
          className="chk-result anim in"
          id="checklist-static-result"
          style={{ marginBottom: 28 }}
        >
          <div className="chk-count">
            <span id="chkNum">{count}</span> de {total} sinais marcados
          </div>
          <div
            className={`chk-verdict ${isAlert ? "alert" : ""}`}
            id="chkVerdict"
          >
            {verdict}
          </div>
          {/* LINHA QUE VAI SE COMPLETANDO AO SELECIONAR */}
          <div className="chk-bar" style={{ marginTop: 14 }}>
            <i style={{ width: `${fillPct}%` }}></i>
          </div>
        </div>

        {/* SESSÃO UNIFICADA E RESUMIDA */}
        <div className="prose anim in" style={{ maxWidth: 740, margin: "0 auto 24px", textAlign: "left" }}>
          <p style={{ fontSize: 16, lineHeight: 1.65 }}>
            Se você sente esses sintomas diariamente, vermes e parasitas estão roubando seus nutrientes e liberando toxinas. O resultado? Seu organismo performa apenas <b>25% da sua capacidade real</b> — você come, mas quem se serve primeiro são eles. É como <span className="em">sustentar um hóspede indesejado à própria mesa</span>: o que sobra para você é o cansaço constante e o abdômen estufado.
          </p>
        </div>

        {/* IMAGEM DO BIOFILME E BLOCO RESUMIDO DO MURO INVISÍVEL */}
        <div className="biofilm-unified-block anim in" style={{ maxWidth: 740, margin: "0 auto" }}>
          <div style={{ borderRadius: 14, overflow: "hidden", boxShadow: "0 10px 28px rgba(0,0,0,0.08)", maxWidth: 640, margin: "0 auto" }}>
            <img
              className="sec-img"
              src="/images/img20.webp"
              alt="Parasita protegido pelo biofilme no intestino"
              loading="eager"
              decoding="async"
              style={{ width: "100%", height: "auto", display: "block" }}
              onError={(e) => {
                e.currentTarget.onerror = null;
                e.currentTarget.src = "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/74f71c4a-aa9f-41b8-8f27-f13d2b586e30.png?v=1789417986";
              }}
            />
          </div>
          <p style={{ textAlign: "center", fontSize: 13, color: "var(--cinza)", fontStyle: "italic", marginTop: 8, marginBottom: 20 }}>
            Parasita protegido pelo biofilme no intestino
          </p>

          <div style={{ textAlign: "center", marginBottom: 12 }}>
            <p className="eyebrow-c" style={{ marginBottom: 4 }}>Por que nada parece funcionar</p>
            <h3 style={{ fontSize: "clamp(20px, 3.8vw, 26px)", color: "var(--verde-esc)", margin: "0 0 10px", lineHeight: 1.25 }}>
              O muro invisível que <span className="green">blinda os parasitas</span>
            </h3>
          </div>

          <div className="prose anim in" style={{ maxWidth: 740, margin: "0 auto", textAlign: "left" }}>
            <p style={{ fontSize: 15.5, lineHeight: 1.6 }}>
              Com o tempo, os invasores criam uma película viscosa e resistente nas paredes do cólon — o <b>biofilme</b>. Essa armadura bloqueia a absorção de nutrientes e impede que remédios ou suplementos tradicionais cheguem até eles.
            </p>
          </div>

          <div className="data anim in" style={{ marginTop: 16 }}>
            Pesquisas em microbiologia mostram que o biofilme pode deixar os parasitas até <span className="n">1000x mais resistentes</span> à ação de remédios e suplementos comuns.
            <span className="src">
              Base científica reconhecida em estudos sobre biofilmes microbianos.
            </span>
          </div>
        </div>
      </div>

      {/* BARRA FIXA NA TELA NESSA SESSÃO COM A LINHA COMPLETANDO AO SELECIONAR */}
      {showFloatingBar && (
        <div className="chk-floating-bar" id="checklist-floating-bar">
          <div className="chk-floating-wrap">
            <div className="chk-floating-head">
              <div className="chk-floating-count">
                <b>{count}</b> de {total} sinais marcados
              </div>
              <div
                className={`chk-floating-verdict ${isAlert ? "alert" : ""}`}
              >
                {count === 0
                  ? "Toque nos sinais para verificar seu nível"
                  : verdict}
              </div>
            </div>
            <div className="chk-bar">
              <i style={{ width: `${fillPct}%` }}></i>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
