import React, { useEffect, useState, useRef } from "react";

interface StockBadgeProps {
  stock: number;
}

export function StockBadgeFloating({ stock }: StockBadgeProps) {
  const [animating, setAnimating] = useState(false);
  const [deductionAmount, setDeductionAmount] = useState<number | null>(null);
  const prevStockRef = useRef(stock);

  useEffect(() => {
    if (stock < prevStockRef.current) {
      const diff = prevStockRef.current - stock;
      setDeductionAmount(diff);
      setAnimating(true);
      const timer = setTimeout(() => {
        setAnimating(false);
        setDeductionAmount(null);
      }, 1200);
      prevStockRef.current = stock;
      return () => clearTimeout(timer);
    }
    prevStockRef.current = stock;
  }, [stock]);

  return (
    <div
      className="stock-ball-wrapper"
      title={`${stock} unidades restantes em estoque`}
    >
      <div className={`stock-ball ${animating ? "stock-ball-pulse" : ""}`}>
        <span className="stock-ball-label">Restam:</span>
        <div className="stock-ball-number-row">
          <span className="stock-ball-count">{stock}</span>
          <span className="stock-ball-unit">unid.</span>
        </div>

        {/* Efeito de flash flutuante quando desconta (-2, -3, -4) */}
        {animating && deductionAmount !== null && (
          <span className="stock-ball-diff">
            -{deductionAmount}
          </span>
        )}
      </div>
    </div>
  );
}
