export function Header() {
  return (
    <>
      <header>
        <div className="header-in">
          <div style={{ gridColumn: 2, display: "flex", alignItems: "center", gap: 8 }}>
            <div className="logo" style={{ cursor: "pointer", userSelect: "none" }}>
              Intest<span style={{ color: "#E87E38", fontWeight: 800 }}>Pura</span>
            </div>
          </div>
          <div className="trust-mini">
            <div>
              <span className="dot"></span> Compra 100% segura
            </div>
            <div>Envio Sedex grátis</div>
            <div>Garantia 90 dias</div>
          </div>
        </div>
      </header>

      <div className="kwbar">
        <div className="track">
          <span>DESTRÓI O BIOFILME</span>
          <span>FIM DOS PARASITAS INTESTINAIS</span>
          <span>BARRIGA CHAPADA E LISA</span>
          <span>AÇÃO BOTÂNICA ANTI-BIOFILME</span>
          <span>SEM CANETAS QUÍMICAS</span>
          <span>FÓRMULA PARASITOLÓGICA</span>
          <span>+120 MIL MULHERES LIVRES</span>
          <span>DESTRÓI O BIOFILME</span>
          <span>FIM DOS PARASITAS INTESTINAIS</span>
          <span>BARRIGA CHAPADA E LISA</span>
          <span>AÇÃO BOTÂNICA ANTI-BIOFILME</span>
          <span>SEM CANETAS QUÍMICAS</span>
          <span>FÓRMULA PARASITOLÓGICA</span>
          <span>+120 MIL MULHERES LIVRES</span>
        </div>
      </div>
    </>
  );
}
