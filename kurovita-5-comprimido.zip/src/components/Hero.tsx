import { useState } from "react";
import { GALLERY_SLIDES } from "../data/intestpuraData";

export function Hero() {
  const [activeSlideIndex, setActiveSlideIndex] = useState(0);

  const currentSlide = GALLERY_SLIDES[activeSlideIndex] || GALLERY_SLIDES[0];

  return (
    <section className="hero">
      <div className="wrap">
        <div className="hero-lead-container" style={{ maxWidth: 720, margin: "0 auto", textAlign: "center" }}>
          <h1 style={{ fontSize: "clamp(26px, 4.5vw, 40px)", margin: "10px 0 14px", lineHeight: 1.2 }}>
            Fim dos parasitas intestinais e da{" "}
            <span className="green">barriga estufada "de grávida"</span>
          </h1>
          <p className="sub" style={{ fontSize: "clamp(15px, 2.5vw, 17px)", color: "#374151", margin: "0 auto 22px", maxWidth: 640 }}>
            — A fórmula da <b>tia parasitologista e de especialistas</b> que rompe o biofilme, paralisa os vermes e devolve a cintura chapada.
          </p>

          <div className="gallery" style={{ maxWidth: 520, margin: "0 auto" }}>
            <div className="prod-img" style={{ aspectRatio: "1 / 1", borderRadius: 16, overflow: "hidden", boxShadow: "0 10px 30px rgba(0,0,0,0.08)" }}>
              <img
                id="mainImg"
                src={currentSlide.mainImg}
                alt={currentSlide.alt}
                fetchPriority="high"
                decoding="async"
                style={{ width: "100%", height: "100%", objectFit: "cover" }}
              />
            </div>
            <div className="thumbs" style={{ marginTop: 12, justifyContent: "center", display: "flex", gap: 10 }}>
              {GALLERY_SLIDES.map((slide, i) => (
                <img
                  key={i}
                  src={slide.thumbImg}
                  alt={slide.alt}
                  loading="lazy"
                  decoding="async"
                  className={activeSlideIndex === i ? "active" : ""}
                  onClick={() => setActiveSlideIndex(i)}
                  style={{
                    width: 72,
                    height: 72,
                    objectFit: "cover",
                    borderRadius: 10,
                    cursor: "pointer",
                    border: activeSlideIndex === i ? "2px solid #ea580c" : "1px solid #e5e7eb",
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
