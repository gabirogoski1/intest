export interface GeoLocation {
  city: string;
  state: string;
  stateCode: string;
  isDetected: boolean;
}

export interface CityItem {
  city: string;
  state: string; // UF, e.g. "SP"
  stateName: string;
}

// 50 to 60+ cities per state for major states, plus extensive coverage across all Brazilian states
export const CITIES_BY_STATE: Record<string, { stateName: string; cities: string[] }> = {
  SP: {
    stateName: "São Paulo",
    cities: [
      "São Paulo", "Guarulhos", "Campinas", "São Bernardo do Campo", "Santo André",
      "Osasco", "São José dos Campos", "Ribeirão Preto", "Sorocaba", "Santos",
      "Mauá", "São José do Rio Preto", "Mogi das Cruzes", "Diadema", "Jundiaí",
      "Piracicaba", "Carapicuíba", "Bauru", "Itaquaquecetuba", "São Vicente",
      "Franca", "Praia Grande", "Guarujá", "Taubaté", "Limeira",
      "Suzano", "Taboão da Serra", "Sumaré", "Barueri", "Embu das Artes",
      "Indaiatuba", "Cotia", "Americana", "Marília", "Itapevi",
      "Araraquara", "Jacareí", "Hortolândia", "Presidente Prudente", "Rio Claro",
      "Araçatuba", "Ferraz de Vasconcelos", "Santa Bárbara d'Oeste", "Francisco Morato", "Itapecerica da Serra",
      "Itu", "Bragança Paulista", "Pindamonhangaba", "São Caetano do Sul", "Itapetininga",
      "Mogi Guaçu", "Jaú", "Botucatu", "Atibaia", "Santana de Parnaíba",
      "Araras", "Valinhos", "Sertãozinho", "Catanduva", "Votorantim",
      "Barretos", "Guaratinguetá", "Caraguatatuba", "Ourinhos", "Salto"
    ],
  },
  RJ: {
    stateName: "Rio de Janeiro",
    cities: [
      "Rio de Janeiro", "São Gonçalo", "Duque de Caxias", "Nova Iguaçu", "Niterói",
      "Belford Roxo", "Campos dos Goytacazes", "São João de Meriti", "Petrópolis", "Volta Redonda",
      "Macaé", "Magé", "Itaboraí", "Cabo Frio", "Angra dos Reis",
      "Nova Friburgo", "Barra Mansa", "Teresópolis", "Mesquita", "Nilópolis",
      "Maricá", "Queimados", "Rio das Ostras", "Resende", "Araruama",
      "Itaguaí", "Itaperuna", "Japeri", "São Pedro da Aldeia", "Barra do Piraí",
      "Seropédica", "Saquarema", "Três Rios", "Valença", "Guapimirim",
      "Paracambi", "Cachoeiras de Macacu", "Armação dos Búzios", "Paraty", "Santo Antônio de Pádua",
      "Mangaratiba", "Casimiro de Abreu", "São Fidélis", "Bom Jesus do Itabapoana", "Vassouras",
      "Silva Jardim", "Miracema", "Piraí", "Rio Bonito", "São Francisco de Itabapoana",
      "Cantagalo", "Itaocara", "Conceição de Macabu", "Cordeiro", "Porciúncula",
      "Carmo", "Arraial do Cabo", "Pinheiral", "Engenheiro Paulo de Frontin", "Quatis"
    ],
  },
  MG: {
    stateName: "Minas Gerais",
    cities: [
      "Belo Horizonte", "Uberlândia", "Contagem", "Juiz de Fora", "Betim",
      "Montes Claros", "Ribeirão das Neves", "Uberaba", "Governador Valadares", "Ipatinga",
      "Sete Lagoas", "Divinópolis", "Santa Luzia", "Ibirité", "Poços de Caldas",
      "Patos de Minas", "Pouso Alegre", "Teófilo Otoni", "Barbacena", "Sabará",
      "Varginha", "Conselheiro Lafaiete", "Vespasiano", "Itabira", "Araguari",
      "Passos", "Ubá", "Coronel Fabriciano", "Muriaé", "Ituiutaba",
      "Lavras", "Nova Serrana", "Itajubá", "Nova Lima", "Paracatu",
      "Pará de Minas", "Caratinga", "São João del-Rei", "Patrocínio", "Timóteo",
      "Manhuaçu", "Unaí", "Curvelo", "Alfenas", "João Monlevade",
      "Três Corações", "Viçosa", "Cataguases", "Ouro Preto", "Janaúba",
      "São Sebastião do Paraíso", "Januária", "Formiga", "Esmeraldas", "Pedro Leopoldo",
      "Ponte Nova", "Mariana", "Frutal", "Três Pontas", "Pirapora"
    ],
  },
  RS: {
    stateName: "Rio Grande do Sul",
    cities: [
      "Porto Alegre", "Caxias do Sul", "Canoas", "Pelotas", "Santa Maria",
      "Gravataí", "Viamão", "Novo Hamburgo", "São Leopoldo", "Rio Grande",
      "Alvorada", "Passo Fundo", "Sapucaia do Sul", "Uruguaiana", "Santa Cruz do Sul",
      "Cachoeirinha", "Bage", "Bento Gonçalves", "Erechim", "Guaíba",
      "Esteio", "Ijuí", "Santana do Livramento", "Sapiranga", "Lajeado",
      "Cachoeira do Sul", "Farroupilha", "Santo Ângelo", "Alegrete", "Santa Rosa",
      "Venâncio Aires", "Campo Bom", "Vacaria", "Montenegro", "Cruz Alta",
      "São Borja", "São Gabriel", "Carazinho", "Taquara", "Canguçu",
      "Parobé", "Santiago", "Camaquã", "Tramandaí", "Estância Velha",
      "Osório", "Canela", "Gramado", "Torres", "Panambi",
      "Marau", "São Lourenço do Sul", "Igrejinha", "Eldorado do Sul", "Flores da Cunha",
      "Charqueadas", "São Luiz Gonzaga", "Rosário do Sul", "Garibaldi", "Rio Pardo"
    ],
  },
  PR: {
    stateName: "Paraná",
    cities: [
      "Curitiba", "Londrina", "Maringá", "Ponta Grossa", "Cascavel",
      "São José dos Pinhais", "Foz do Iguaçu", "Colombo", "Guarapuava", "Paranaguá",
      "Araucária", "Toledo", "Apucarana", "Pinhais", "Campo Largo",
      "Arapongas", "Almirante Tamandaré", "Piraquara", "Umuarama", "Cambé",
      "Fazenda Rio Grande", "Sarandi", "Campo Mourão", "Francisco Beltrão", "Paranavaí",
      "Pato Branco", "Cianorte", "Telêmaco Borba", "Castro", "Rolândia",
      "Irati", "União da Vitória", "Ibiporã", "Prudentópolis", "Marechal Cândido Rondon",
      "Cornélio Procópio", "Palmas", "Santo Antônio da Platina", "São Mateus do Sul", "Medianeira",
      "Campina Grande do Sul", "Paiçandu", "Jacarezinho", "Dois Vizinhos", "Guaratuba",
      "Matinhos", "Jandaia do Sul", "Lapa", "Rio Branco do Sul", "Mandaguari",
      "Assis Chateaubriand", "Palotina", "Porecatu", "Quedas do Iguaçu", "Guaíra",
      "Ivaiporã", "Bandeirantes", "Loanda", "Antonina", "Morretes"
    ],
  },
  SC: {
    stateName: "Santa Catarina",
    cities: [
      "Florianópolis", "Joinville", "Blumenau", "São José", "Itajaí",
      "Chapecó", "Criciúma", "Jaraguá do Sul", "Palhoça", "Lages",
      "Balneário Camboriú", "Brusque", "Tubarão", "São Bento do Sul", "Caçador",
      "Camboriú", "Navegantes", "Concórdia", "Rio do Sul", "Gaspar",
      "Biguaçu", "Indaial", "Itapema", "Mafra", "Canoinhas",
      "Içara", "Videira", "São Francisco do Sul", "Xanxerê", "Guaramirim",
      "Tijucas", "Araranguá", "Laguna", "Timbó", "Rio Negrinho",
      "São Miguel do Oeste", "Curitibanos", "Porto União", "Campos Novos", "Fraiburgo",
      "Imbituba", "Penha", "Pomerode", "Braço do Norte", "Garuva",
      "Joaçaba", "São Lourenço do Oeste", "Sombrio", "Ituporanga", "Pinhalzinho",
      "Maravilha", "Capivari de Baixo", "Urussanga", "Orleans", "Porto Belo",
      "Balneário Piçarras", "Herval d'Oeste", "Forquilhinha", "Papanduva", "Santo Amaro da Imperatriz"
    ],
  },
  BA: {
    stateName: "Bahia",
    cities: [
      "Salvador", "Feira de Santana", "Vitória da Conquista", "Camaçari", "Juazeiro",
      "Itabuna", "Lauro de Freitas", "Ilhéus", "Jequié", "Teixeira de Freitas",
      "Alagoinhas", "Barreiras", "Porto Seguro", "Simões Filho", "Paulo Afonso",
      "Eunápolis", "Santo Antônio de Jesus", "Valença", "Candeias", "Guanambi",
      "Jacobina", "Serrinha", "Senhor do Bonfim", "Dias d'Ávila", "Luís Eduardo Magalhães",
      "Itapetinga", "Irecê", "Campo Formoso", "Casa Nova", "Bom Jesus da Lapa",
      "Brumado", "Conceição do Coité", "Itamaraju", "Itaberaba", "Cruz das Almas",
      "Ipirá", "Santo Amaro", "Euclides da Cunha", "Catu", "Jaguaquara",
      "Ribeira do Pombal", "Barra", "Poções", "Santo Estêvão", "Caetité",
      "Tucano", "Macaúbas", "Monte Santo", "Mata de São João", "Vera Cruz",
      "Ipiaú", "Maracás", "Livramento de Nossa Senhora", "Seabra", "Amargosa",
      "Morro do Chapéu", "Santa Maria da Vitória", "Remanso", "Canavieiras", "Prado"
    ],
  },
  PE: {
    stateName: "Pernambuco",
    cities: [
      "Recife", "Jaboatão dos Guararapes", "Olinda", "Caruaru", "Petrolina",
      "Paulista", "Cabo de Santo Agostinho", "Camaragibe", "Garanhuns", "Vitória de Santo Antão",
      "Igarassu", "São Lourenço da Mata", "Santa Cruz do Capibaribe", "Abreu e Lima", "Ipojuca",
      "Serra Talhada", "Araripina", "Gravatá", "Carpina", "Goiana",
      "Belo Jardim", "Arcoverde", "Ouricuri", "Escada", "Pesqueira",
      "Surubim", "Palmares", "Bezerros", "Moreno", "Salgueiro",
      "São Bento do Una", "Buíque", "Paudalho", "Limoeiro", "Timbaúba",
      "Brejo da Madre de Deus", "Bom Conselho", "Santa Maria da Boa Vista", "Lajedo", "Toritama",
      "Sirinhaém", "Custódia", "Águas Belas", "Afogados da Ingazeira", "Taquaritinga do Norte",
      "São José do Egito", "Ribeirão", "Cabrobó", "Petrolândia", "Alagoinha"
    ],
  },
  CE: {
    stateName: "Ceará",
    cities: [
      "Fortaleza", "Caucaia", "Juazeiro do Norte", "Maracanaú", "Sobral",
      "Crato", "Itapipoca", "Maranguape", "Iguatu", "Quixadá",
      "Pacatuba", "Aquiraz", "Quixeramobim", "Canindé", "Russas",
      "Tianguá", "Crateús", "Aracati", "Cascavel", "Pacajus",
      "Icó", "Horizonte", "Camocim", "Morada Nova", "Acaraú",
      "Viçosa do Ceará", "Barbalha", "Limoeiro do Norte", "Tauá", "Trairi",
      "Granja", "Boa Viagem", "São Gonçalo do Amarante", "Acopiara", "Beberibe",
      "Eusébio", "Itapajé", "Brejo Santo", "Mauriti", "Senador Pompeu",
      "Mombaça", "Jaguaribe", "Pedra Branca", "Baturité", "Ipu",
      "Santa Quitéria", "Várzea Alegre", "Guaraciaba do Norte", "Ubajara", "Jardim"
    ],
  },
  GO: {
    stateName: "Goiás",
    cities: [
      "Goiânia", "Aparecida de Goiânia", "Anápolis", "Rio Verde", "Luziânia",
      "Águas Lindas de Goiás", "Valparaíso de Goiás", "Trindade", "Formosa", "Novo Gama",
      "Senador Canedo", "Itumbiara", "Catalão", "Jataí", "Planaltina",
      "Caldas Novas", "Santo Antônio do Descoberto", "Cidade Ocidental", "Goianésia", "Mineiros",
      "Cristalina", "Inhumas", "Jaraguá", "Quirinópolis", "Niquelândia",
      "Morrinhos", "Goiatuba", "Porangatu", "Santa Helena de Goiás", "Posse",
      "São Luís de Montes Belos", "Pires do Rio", "Iporá", "Uruaçu", "Padre Bernardo",
      "Minaçu", "Goiás Velho", "Palmeiras de Goiás", "Alexânia", "Ceres",
      "Piracanjuba", "Bela Vista de Goiás", "Ipameri", "Itaberaí", "Nerópolis",
      "Rubiataba", "Anicuns", "Hidrolândia", "Pontalina", "Campos Belos"
    ],
  },
  DF: {
    stateName: "Distrito Federal",
    cities: [
      "Brasília", "Ceilândia", "Taguatinga", "Samambaia", "Plano Piloto",
      "Águas Claras", "Guará", "Gama", "Recanto das Emas", "Santa Maria",
      "Sobradinho", "Vicente Pires", "São Sebastião", "Riacho Fundo", "Planaltina",
      "Sudoeste/Octogonal", "Cruzeiro", "Lago Sul", "Lago Norte", "Núcleo Bandeirante",
      "Brazlândia", "Paranoá", "Itapoã", "Jardim Botânico", "Candangolândia"
    ],
  },
  ES: {
    stateName: "Espírito Santo",
    cities: [
      "Vitória", "Vila Velha", "Serra", "Cariacica", "Cachoeiro de Itapemirim",
      "Linhares", "São Mateus", "Colatina", "Guarapari", "Aracruz",
      "Viana", "Nova Venécia", "Barra de São Francisco", "Marataízes", "Castelo",
      "Santa Maria de Jetibá", "Domingos Martins", "Itapemirim", "Afonso Cláudio", "Alegre",
      "Baixo Guandu", "Guaçuí", "Iúna", "Sooretama", "Jaguaré",
      "Anchieta", "Pinheiros", "Conceição da Barra", "Mimoso do Sul", "Ibatiba",
      "Venda Nova do Imigrante", "Pancas", "Ecoporanga", "Piúma", "Fundão",
      "Montanha", "Muqui", "João Neiva", "Santa Teresa", "Vargem Alta"
    ],
  },
  MT: {
    stateName: "Mato Grosso",
    cities: [
      "Cuiabá", "Várzea Grande", "Rondonópolis", "Sinop", "Tangará da Serra",
      "Sorriso", "Lucas do Rio Verde", "Primavera do Leste", "Barra do Garças", "Alta Floresta",
      "Cáceres", "Nova Mutum", "Campo Verde", "Pontes e Lacerda", "Juína",
      "Juara", "Colíder", "Guarantã do Norte", "Peixoto de Azevedo", "Barra do Bugres",
      "Campo Novo do Parecis", "Diamantino", "Canarana", "Mirassol d'Oeste", "Água Boa",
      "Chapada dos Guimarães", "Poconé", "Sapezal", "Vila Rica", "Jaciara"
    ],
  },
  MS: {
    stateName: "Mato Grosso do Sul",
    cities: [
      "Campo Grande", "Dourados", "Três Lagoas", "Corumbá", "Ponta Porã",
      "Sidrolândia", "Naviraí", "Nova Andradina", "Aquidauana", "Maracaju",
      "Paranaíba", "Amambai", "Rio Brilhante", "Coxim", "Caarapó",
      "Miranda", "São Gabriel do Oeste", "Jardim", "Aparecida do Taboado", "Anastácio",
      "Chapadão do Sul", "Bonito", "Ribas do Rio Pardo", "Bela Vista", "Ivinhema"
    ],
  },
  PR_SC_RS: {
    stateName: "Região Sul",
    cities: [
      "Curitiba", "Porto Alegre", "Florianópolis", "Londrina", "Caxias do Sul", "Joinville",
      "Maringá", "Pelotas", "Blumenau", "Ponta Grossa", "Canoas", "São José"
    ]
  },
  PA: {
    stateName: "Pará",
    cities: [
      "Belém", "Ananindeua", "Santarém", "Marabá", "Parauapebas",
      "Castanhal", "Abaetetuba", "Cametá", "Marituba", "Bragança",
      "São Félix do Xingu", "Barcarena", "Altamira", "Tucuruí", "Paragominas",
      "Tailândia", "Breves", "Itaituba", "Redenção", "Moju"
    ],
  },
  AM: {
    stateName: "Amazonas",
    cities: [
      "Manaus", "Parintins", "Itacoatiara", "Manacapuru", "Coari",
      "Tabatinga", "Maués", "Tefé", "Manicoré", "Humaitá",
      "Iranduba", "Lábrea", "São Gabriel da Cachoeira", "Borba", "Autazes"
    ],
  },
  RN: {
    stateName: "Rio Grande do Norte",
    cities: [
      "Natal", "Mossoró", "Parnamirim", "São Gonçalo do Amarante", "Macaíba",
      "Ceará-Mirim", "Caicó", "Açu", "Currais Novos", "São José de Mipibu",
      "Santa Cruz", "Nova Cruz", "Apodi", "João Câmara", "Touros"
    ],
  },
  PB: {
    stateName: "Paraíba",
    cities: [
      "João Pessoa", "Campina Grande", "Santa Rita", "Patos", "Bayeux",
      "Sousa", "Cajazeiras", "Cabedelo", "Guarabira", "Mamanguape",
      "Queimadas", "São Bento", "Monteiro", "Esperança", "Pombal"
    ],
  },
  MA: {
    stateName: "Maranhão",
    cities: [
      "São Luís", "Imperatriz", "São José de Ribamar", "Timon", "Caxias",
      "Codó", "Paço do Lumiar", "Açailândia", "Bacabal", "Balsas",
      "Santa Inês", "Barra do Corda", "Pinheiro", "Chapadinha", "Santa Luzia"
    ],
  },
  AL: {
    stateName: "Alagoas",
    cities: [
      "Maceió", "Arapiraca", "Rio Largo", "Palmeira dos Índios", "União dos Palmares",
      "Penedo", "São Miguel dos Campos", "Coruripe", "Campo Alegre", "Delmiro Gouveia"
    ],
  },
  PI: {
    stateName: "Piauí",
    cities: [
      "Teresina", "Parnaíba", "Picos", "Piripiri", "Floriano",
      "Barras", "Campo Maior", "União", "Altos", "Esperantina"
    ],
  },
  SE: {
    stateName: "Sergipe",
    cities: [
      "Aracaju", "Nossa Senhora do Socorro", "Lagarto", "Itabaiana", "São Cristóvão",
      "Estância", "Tobias Barreto", "Simão Dias", "Itabaianinha", "Poço Redondo"
    ],
  },
  RO: {
    stateName: "Rondônia",
    cities: [
      "Porto Velho", "Ji-Paraná", "Ariquemes", "Vilhena", "Cacoal",
      "Rolim de Moura", "Jaru", "Guajará-Mirim", "Ouro Preto do Oeste", "Pimenta Bueno"
    ],
  },
  TO: {
    stateName: "Tocantins",
    cities: [
      "Palmas", "Araguaína", "Gurupi", "Porto Nacional", "Paraíso do Tocantins",
      "Colinas do Tocantins", "Guaraí", "Tocantinópolis", "Dianópolis", "Miracema do Tocantins"
    ],
  },
  AP: {
    stateName: "Amapá",
    cities: [
      "Macapá", "Santana", "Laranjal do Jari", "Oiapoque", "Porto Grande", "Mazagão"
    ],
  },
  AC: {
    stateName: "Acre",
    cities: [
      "Rio Branco", "Cruzeiro do Sul", "Sena Madureira", "Tarauacá", "Feijó", "Brasiléia"
    ],
  },
  RR: {
    stateName: "Roraima",
    cities: [
      "Boa Vista", "Rorainópolis", "Caracaraí", "Pacaraima", "Cantá"
    ],
  },
};

export const BRAZIL_CUSTOMER_NAMES = [
  "Juliana", "Mariana", "Patrícia", "Camila", "Fernanda",
  "Renata", "Beatriz", "Aline", "Débora", "Larissa",
  "Vanessa", "Luciana", "Tatiane", "Carla", "Priscila",
  "Cláudia", "Sílvia", "Daniela", "Simone", "Márcia",
  "Cristina", "Sandra", "Amanda", "Flávia", "Eliane",
  "Adriana", "Roberta", "Sabrina", "Mônica", "Helena",
  "Gisele", "Viviane", "Paula", "Regina", "Raquel"
];

let cachedGeo: GeoLocation | null = null;

export async function detectUserLocation(): Promise<GeoLocation> {
  if (cachedGeo) return cachedGeo;

  // Check sessionStorage
  try {
    const saved = sessionStorage.getItem("intestpura_geo_cache");
    if (saved) {
      cachedGeo = JSON.parse(saved);
      if (cachedGeo) return cachedGeo;
    }
  } catch {
    // Ignore storage errors
  }

  // Fast fetch with 2s timeout
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000);

    const res = await fetch("https://ipwho.is/?lang=pt-BR", {
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      if (data && data.success && data.country_code === "BR") {
        const result: GeoLocation = {
          city: data.city || "",
          state: data.region || "",
          stateCode: data.region_code || "",
          isDetected: true,
        };
        cachedGeo = result;
        try {
          sessionStorage.setItem("intestpura_geo_cache", JSON.stringify(result));
        } catch {
          // Ignore
        }
        return result;
      }
    }
  } catch {
    // Timeout or network error
  }

  // Fallback default
  const fallback: GeoLocation = {
    city: "",
    state: "seu estado",
    stateCode: "BR",
    isDetected: false,
  };
  cachedGeo = fallback;
  return fallback;
}

/**
 * Builds the sales queue prioritizing ONLY cities close to the lead (from their own state).
 * - If user's state is detected, returns ONLY cities of that state (up to 60+ cities saved).
 * - If user's specific city is detected, it is placed right near the start along with its neighbors.
 * - If state is not detected, returns a national list of top Brazilian cities.
 */
export function buildSalesQueue(stateCode: string, userCity?: string): CityItem[] {
  const normState = (stateCode || "").toUpperCase().trim();
  const stateData = CITIES_BY_STATE[normState];

  if (stateData && stateData.cities.length > 0) {
    const cityList = [...stateData.cities];

    // If user's city exists in or can be added to the list, prioritize it
    const normalizedUserCity = (userCity || "").trim().toLowerCase();
    
    // Sort: user's city first, then shuffle the rest of the 50-60+ state cities
    const prioritized: CityItem[] = [];

    if (userCity && userCity.length > 2) {
      prioritized.push({
        city: userCity,
        state: normState,
        stateName: stateData.stateName,
      });
    }

    const remaining = cityList
      .filter((c) => c.toLowerCase() !== normalizedUserCity)
      .sort(() => 0.5 - Math.random());

    for (const c of remaining) {
      prioritized.push({
        city: c,
        state: normState,
        stateName: stateData.stateName,
      });
    }

    return prioritized;
  }

  // Fallback: If no state detected, build from across Brazil
  const fallbackList: CityItem[] = [];
  const states = Object.keys(CITIES_BY_STATE);
  for (const st of states) {
    const data = CITIES_BY_STATE[st];
    const topFew = data.cities.slice(0, 3);
    for (const c of topFew) {
      fallbackList.push({
        city: c,
        state: st,
        stateName: data.stateName,
      });
    }
  }

  return fallbackList.sort(() => 0.5 - Math.random());
}
