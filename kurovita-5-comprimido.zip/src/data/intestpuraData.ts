export interface KitOffer {
  id: string;
  tag: string;
  tagClass: string;
  qty: string;
  thumbClass: string;
  image: string;
  title: string;
  subtitle: string;
  oldPrice: string;
  newPrice: string;
  url: string;
  bottles: number;
  hideQtyBadge?: boolean;
  bonusGift?: string;
}

// URL da imagem de 6 potes (COMPRE 3 · LEVE 6) - Já configurada para ocultar a faixa laranja
export const IMAGE_KIT_6_POTES =
  "https://cdn.shopify.com/s/files/1/1010/4150/4546/files/5bcf23c4-8009-4ff5-b508-6ce2d7c84824_79977853-6647-4a86-b093-9ea6cfcc885a.png?v=1789936076";

// URL da imagem antes e depois da Maria Garcia
export const IMAGE_MARIA_GARCIA_BEFORE_AFTER =
  "https://cdn.shopify.com/s/files/1/1010/4150/4546/files/86e9cb1e-7fe0-4f14-97ef-045daf7b9b16.png?v=1790269123";

export const KITS: KitOffer[] = [
  {
    id: "kit-3",
    tag: "Mais Vendido",
    tagClass: "tag-green",
    qty: "3 POTES",
    thumbClass: "k3",
    image: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/8ce3ab86-6b88-4467-b21d-a41464b0d5ed.png?v=1789349359",
    title: "COMPRE 2 · LEVE 3",
    subtitle: "Protocolo 90 dias · Economize 56%",
    oldPrice: "R$ 449,90",
    newPrice: "R$ 199,90",
    url: "https://seguro.vitaissuplementos.com/api/public/shopify?product=52550924468514&store=34723",
    bottles: 3,
  },
  {
    id: "kit-6",
    tag: "Melhor Valor",
    tagClass: "tag-teal",
    qty: "6 POTES",
    thumbClass: "k6",
    image: IMAGE_KIT_6_POTES,
    title: "COMPRE 3 · LEVE 6",
    subtitle: "Protocolo completo 180 dias · Economize 67%",
    oldPrice: "R$ 899,90",
    newPrice: "R$ 299,90",
    url: "https://seguro.vitaissuplementos.com/api/public/shopify?product=52550932955426&store=34723",
    bottles: 6,
    hideQtyBadge: true,
    bonusGift: "Brinde: Cinta modeladora",
  },
  {
    id: "kit-2",
    tag: "50% OFF",
    tagClass: "tag-lime",
    qty: "2 POTES",
    thumbClass: "k2",
    image: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/d2750d24-c18a-480e-ac4c-509cbeb2f4ad.png?v=1789349245",
    title: "COMPRE 1 · LEVE 2",
    subtitle: "Protocolo 60 dias · Economize 50%",
    oldPrice: "R$ 299,90",
    newPrice: "R$ 149,90",
    url: "https://seguro.vitaissuplementos.com/api/public/shopify?product=52550920339746&store=34723",
    bottles: 2,
  },
];

// 30% OFF Discounted Kits activated via Exit Intent
export const KITS_DISCOUNTED_30: KitOffer[] = [
  {
    id: "kit-3",
    tag: "🔥 30% EXTRA · MAIS VENDIDO",
    tagClass: "tag-green",
    qty: "3 POTES",
    thumbClass: "k3",
    image: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/8ce3ab86-6b88-4467-b21d-a41464b0d5ed.png?v=1789349359",
    title: "COMPRE 2 · LEVE 3",
    subtitle: "Desconto de 30% aplicado · 12x de R$ 14,05",
    oldPrice: "R$ 199,90",
    newPrice: "R$ 139,90",
    url: "https://seguro.vitaissuplementos.com/api/public/shopify?product=52550924468514&store=34723",
    bottles: 3,
  },
  {
    id: "kit-6",
    tag: "🔥 30% EXTRA · MELHOR VALOR",
    tagClass: "tag-teal",
    qty: "6 POTES",
    thumbClass: "k6",
    image: IMAGE_KIT_6_POTES,
    title: "COMPRE 3 · LEVE 6",
    subtitle: "Desconto de 30% aplicado · 12x de R$ 21,07",
    oldPrice: "R$ 299,90",
    newPrice: "R$ 209,90",
    url: "https://seguro.vitaissuplementos.com/api/public/shopify?product=52550932955426&store=34723",
    bottles: 6,
    hideQtyBadge: true,
    bonusGift: "Brinde: Cinta modeladora",
  },
  {
    id: "kit-2",
    tag: "🔥 30% EXTRA",
    tagClass: "tag-lime",
    qty: "2 POTES",
    thumbClass: "k2",
    image: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/d2750d24-c18a-480e-ac4c-509cbeb2f4ad.png?v=1789349245",
    title: "COMPRE 1 · LEVE 2",
    subtitle: "Desconto de 30% aplicado · 12x de R$ 10,53",
    oldPrice: "R$ 149,90",
    newPrice: "R$ 104,90",
    url: "https://seguro.vitaissuplementos.com/api/public/shopify?product=52550920339746&store=34723",
    bottles: 2,
  },
];

export interface WhatsAppTestimonial {
  id: string;
  name: string;
  city: string;
  state: string;
  avatar: string;
  time: string;
  mediaUrl: string;
  mediaCaption: string;
  message: string;
  supportReply?: string;
  reactions: string[];
}

export const WHATSAPP_TESTIMONIALS: WhatsAppTestimonial[] = [
  {
    id: "wa-1",
    name: "Fernanda Alencar",
    city: "Campinas",
    state: "SP",
    avatar: "/src/assets/images/fernanda_profile_avatar_1791250347947.jpg",
    time: "11:42",
    mediaUrl: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/c8332e77-f32f-45ab-91a0-a1ce8df39c98.png?v=1789505217",
    mediaCaption: "📦 Caixinha do Intestpura recebida via Sedex em Campinas",
    message: "Chegou minha caixinha aqui em Campinas em 2 dias via Sedex! 🚚💨 Embalagem super discreta. Já tomei minhas 2 primeiras cápsulas hoje no almoço! ❤️👏",
    supportReply: "Que maravilha, Fernanda! 🥰 Muito feliz por você iniciar o ciclo. Beba bastante água durante o dia para potencializar!",
    reactions: ["❤️", "🙏"],
  },
  {
    id: "wa-2",
    name: "Renata Guimarães",
    city: "Belo Horizonte",
    state: "MG",
    avatar: "/src/assets/images/renata_profile_avatar_1791250357381.jpg",
    time: "14:18",
    mediaUrl: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/e41162b7-ee56-478d-bf4a-db030e598e5d.png?v=1789504622",
    mediaCaption: "🌿 7º dia tomando o Intestpura certinho em casa",
    message: "Estou no 7º dia e minha barriga que vivia dura parecendo gravidez murchou de vez! 😱 Hoje ela tá lisinha, leve e sem estufamento após comer. Gratidão demais!",
    supportReply: "Relato emocionante, Renata! A quebra do biofilme nos primeiros dias faz exatamente esse expurgo profundo. Continue firme!",
    reactions: ["👏", "✨"],
  },
  {
    id: "wa-3",
    name: "Cláudia Silveira",
    city: "Curitiba",
    state: "PR",
    avatar: "/images/wa_claudia_avatar.webp",
    time: "09:35",
    mediaUrl: "/images/wa_claudia_espelho.jpg",
    mediaCaption: "📸 Foto no espelho com 21 dias de uso (calça fechando!)",
    message: "Olha a foto no espelho com 21 dias de uso! A pochete rígida de gases e toxinas murchou por completo. Minha calça 40 que não fechava agora fecha com folga! 🙏✨",
    supportReply: "Uau, Cláudia! Que transformação nítida na cintura e no abdômen! Parabéns pelo foco!",
    reactions: ["🔥", "😍"],
  },
];

export interface GallerySlide {
  mainImg: string;
  thumbImg: string;
  alt: string;
}

export const GALLERY_SLIDES: GallerySlide[] = [
  {
    mainImg: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Gelatidina_em_po_regula_o_intestino_1.jpg?v=1789415086",
    thumbImg: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Gelatidina_em_po_regula_o_intestino_1.jpg?v=1789415086",
    alt: "6 benefícios em 1 do Intestpura",
  },
  {
    mainImg: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Gelatidina_em_po_regula_o_intestino.jpg?v=1789414477",
    thumbImg: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/Gelatidina_em_po_regula_o_intestino.jpg?v=1789414477",
    alt: "Composição limpa botânica",
  },
  {
    mainImg: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/bdc6f6a6-618b-4c62-bc79-1a1491a21b1c.png?v=1789351046",
    thumbImg: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/bdc6f6a6-618b-4c62-bc79-1a1491a21b1c.png?v=1789351046",
    alt: "Como tomar o Intestpura",
  },
  {
    mainImg: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/64dc4024-f7bf-4255-8d22-f205f6f64f84.png?v=1789416978",
    thumbImg: "https://cdn.shopify.com/s/files/1/0619/5075/5023/files/64dc4024-f7bf-4255-8d22-f205f6f64f84.png?v=1789416978",
    alt: "Eliminação e barriga chapada",
  },
];

export interface SymptomItem {
  id: number;
  name: string;
  explanation: string;
}

export const SYMPTOMS: SymptomItem[] = [
  {
    id: 1,
    name: "Barriga estufada ('efeito grávida') que incha ao longo do dia",
    explanation: "Gases tóxicos sob o biofilme fermentam e inflam o abdômen como um balão.",
  },
  {
    id: 2,
    name: "Cansaço crônico que não passa, nem dormindo 8 horas",
    explanation: "Parasitas drenam nutrientes vitais antes das células, gerando esgotamento contínuo.",
  },
  {
    id: 3,
    name: "Vontade incontrolável de doce e carboidratos à noite",
    explanation: "Parasitas manipulam seus sinais de apetite para exigir açúcar constante.",
  },
  {
    id: 4,
    name: "Intestino travado ou alternando entre preso e solto",
    explanation: "Biofilme espesso inflama a mucosa e paralisa o trânsito intestinal regular.",
  },
  {
    id: 5,
    name: "Gordura abdominal e retenção que não saem com dieta nem canetas",
    explanation: "Metabolismo travado pelo biofilme, acumulando gordura e retendo líquidos.",
  },
];

export interface BeforeAfterItem {
  img: string;
  alt: string;
}

export const BEFORE_AFTER_ITEMS: BeforeAfterItem[] = [
  { img: "/images/img28.webp", alt: "Antes e depois — barriga lisa e desinchada Intestpura" },
  { img: "/images/img29.webp", alt: "Antes e depois — transformação Intestpura" },
  { img: "/images/img30.webp", alt: "Antes e depois — eliminação de parasitas e estufamento" },
  { img: "/images/img31.webp", alt: "Antes e depois — cintura fina e leveza Intestpura" },
  { img: "/images/img32.webp", alt: "Antes e depois — transformação corporal" },
  { img: "/images/img33.webp", alt: "Antes e depois — barriga chapada sem inchaço" },
];

export interface CustomerReview {
  avatar: string;
  name: string;
  verified: boolean;
  stars: string;
  text: string;
  date: string;
}

export const REVIEWS: CustomerReview[] = [
  {
    avatar: "/images/img34.webp",
    name: "Maria Helena S., 52 anos",
    verified: true,
    stars: "★★★★★",
    text: "Eu tinha exatamente essa barriga de grávida das 15h que me dava vergonha até de colocar blusa justa. Já tinha tentado caneta cara e só passei mal. Com o Intestpura, no 5º dia já notei minha barriga murchando e hoje tenho a cintura que não via há 20 anos!",
    date: "12 de setembro de 2026",
  },
  {
    avatar: "https://cdn.shopify.com/s/files/1/1010/4150/4546/files/1540dbdd-c401-4bd0-acd1-1330de2aff68.png?v=1789692812",
    name: "Renata C., 48 anos",
    verified: true,
    stars: "★★★★★",
    text: "O que me surpreendeu foi a paz mental logo nos primeiros dias e a energia que voltou. A barriga dura e dolorida sumiu por completo. É inacreditável o quanto o biofilme e esses parasitas roubavam a nossa vida.",
    date: "10 de setembro de 2026",
  },
  {
    avatar: "/images/img36.webp",
    name: "Tatiane F., 44 anos",
    verified: true,
    stars: "★★★★★",
    text: "Não tem gosto forte, super fácil de tomar. Esse protocolo botânico realmente fez o que nenhum remédio da farmácia tinha feito. Minha digestão virou um relógio.",
    date: "8 de setembro de 2026",
  },
  {
    avatar: "https://cdn.shopify.com/s/files/1/1010/4150/4546/files/e41162b7-ee56-478d-bf4a-db030e598e5d.png?v=1789692810",
    name: "Lúcia M., 56 anos",
    verified: true,
    stars: "★★★★★",
    text: "Fiquei chocada com a quantidade de toxinas que meu corpo expeliu na primeira semana. Minha barriga desinchou tanto que voltei a usar minhas roupas de alfaiataria que estavam encostadas no armário.",
    date: "6 de setembro de 2026",
  },
  {
    avatar: "/images/img38.webp",
    name: "Marta S., 51 anos",
    verified: true,
    stars: "★★★★★",
    text: "Minha autoestima estava no chão por causa do inchaço e cansaço. Parecia que meu marido nem me enxergava mais. Hoje me sinto leve, jovem, com a barriga lisinha e uma disposição maravilhosa.",
    date: "4 de setembro de 2026",
  },
  {
    avatar: "https://cdn.shopify.com/s/files/1/1010/4150/4546/files/075a4ff6-1bed-44cb-ba8a-aee224cff2ad.png?v=1789692811",
    name: "Silvana B., 49 anos",
    verified: true,
    stars: "★★★★★",
    text: "Parecia mágica, mas é pura ciência botânica. Aquele estufamento horrível pós-almoço simplesmente não existe mais. Perdi 6cm de cintura em um mês de protocolo!",
    date: "1 de setembro de 2026",
  },
  {
    avatar: "/images/img40.webp",
    name: "Simone A., 53 anos",
    verified: true,
    stars: "★★★★★",
    text: "A vontade incontrolável de comer doce à noite acabou na segunda semana. Agora durmo a noite toda sem acordar de madrugada. O Intestpura me devolveu a vida.",
    date: "29 de agosto de 2026",
  },
  {
    avatar: "https://cdn.shopify.com/s/files/1/1010/4150/4546/files/d7b66d76-53b6-4e3e-b141-2e001ae3280b.png?v=1789692809",
    name: "Carla E., 47 anos",
    verified: true,
    stars: "★★★★★",
    text: "Minha tia também já falava que o segredo estava em quebrar o biofilme com compostos botânicos ancestrais. Esse produto encapsulado facilitou tudo. Resultado rápido e comprovado.",
    date: "27 de agosto de 2026",
  },
  {
    avatar: "/images/img42.webp",
    name: "Vanessa L., 42 anos",
    verified: true,
    stars: "★★★★★",
    text: "Valeu cada centavo. Minha barriga que parecia de 5 meses desinchou totalmente. Me sinto bonita e segura de novo!",
    date: "25 de agosto de 2026",
  },
  {
    avatar: "https://cdn.shopify.com/s/files/1/1010/4150/4546/files/89628421-9ca4-4912-8250-68304bffc821.png?v=1789692809",
    name: "Rosana P., 55 anos",
    verified: true,
    stars: "★★★★☆",
    text: "A névoa mental sumiu e meu raciocínio está rápido. Minhas amigas até perguntaram o que eu fiz para emagrecer tão rápido sem flacidez.",
    date: "22 de agosto de 2026",
  },
  {
    avatar: "/images/img44.webp",
    name: "Débora S., 50 anos",
    verified: true,
    stars: "★★★★★",
    text: "Meu intestino funcionava a cada 4 dias com muita dor. Hoje funciona todos os dias pela manhã sem cólica nenhuma. O abdômen fica lisinho o dia todo!",
    date: "20 de agosto de 2026",
  },
  {
    avatar: "https://cdn.shopify.com/s/files/1/1010/4150/4546/files/74fb2730-fe08-462a-bf79-9e12977ff5b5.png?v=1789692809",
    name: "Patrícia H., 46 anos",
    verified: true,
    stars: "★★★★★",
    text: "Comprei o kit de 6 potes para fazer o ciclo completo. Foi a melhor decisão do meu ano. Barriga chapada e zero estresse.",
    date: "18 de agosto de 2026",
  },
];

export interface FaqQuestion {
  question: string;
  answer: string;
}

export const FAQS: FaqQuestion[] = [
  {
    question: "Como exatamente a fórmula do Intestpura funciona?",
    answer: "O Intestpura combina semente de abóbora, cravo e óleos botânicos que dissolvem o biofilme e paralisam os parasitas, eliminando a fermentação de gases e a barriga estufada pela raiz.",
  },
  {
    question: "Por que o Intestpura é diferente de canetas emagrecedoras, chás e vermífugos de farmácia?",
    answer: "Métodos tradicionais não penetram o biofilme e causam efeito rebote. O Intestpura rompe essa carapaça protetora de forma natural, expulsando os invasores sem agredir o estômago.",
  },
  {
    question: "Quanto tempo demora para a barriga desinchar e os resultados aparecerem?",
    answer: "A expulsão começa entre o 2º e o 4º dia. Entre o 7º e o 10º dia a maioria das mulheres já nota a barriga desinchando visivelmente e a cintura afinando.",
  },
  {
    question: "Como devo tomar o Intestpura?",
    answer: "Tome 2 cápsulas por dia com água junto à sua primeira refeição. Cada frasco contém 60 cápsulas, suficiente para 30 dias de tratamento.",
  },
  {
    question: "A fórmula é segura? Tem algum efeito colateral?",
    answer: "Sim, é 100% botânica, pura e segura. Não vicia, não causa diarreia agressiva e não agride a mucosa estomacal.",
  },
  {
    question: "E se eu não gostar? Como funciona a Garantia de 90 Dias?",
    answer: "Você tem 90 dias de teste sem riscos. Se não desinchar ou não ficar satisfeita, devolvemos 100% do seu dinheiro sem perguntas.",
  },
  {
    question: "Quanto tempo para receber meu pedido?",
    answer: "O envio é imediato via Sedex com Frete Grátis. O prazo médio de entrega é de 2 a 4 dias úteis com código de rastreamento por e-mail.",
  },
];

export const SALES_POP_DATA = [
  { name: "Juliana", city: "de Vitória-ES" },
  { name: "Marcos", city: "de Curitiba-PR" },
  { name: "Sônia", city: "de Salvador-BA" },
  { name: "Ricardo", city: "de Belo Horizonte-MG" },
  { name: "Aline", city: "de Fortaleza-CE" },
  { name: "André", city: "de Campinas-SP" },
  { name: "Patrícia", city: "de Goiânia-GO" },
  { name: "Sérgio", city: "de Recife-PE" },
  { name: "Fernanda", city: "de Porto Alegre-RS" },
];
